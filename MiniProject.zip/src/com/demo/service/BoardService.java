package com.demo.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.beans.ContentBean;
import com.demo.beans.LoginUserBean;
import com.demo.mapper.BoardMapper;

@Service
public class BoardService {

	@Autowired
	private BoardMapper boardMapper;

	@Resource(name = "loginUserBean")
	private LoginUserBean loginUserBean;


	public void addContentInfo(ContentBean writeContentBean) {
		System.out.println(writeContentBean.getContent_subject());
		System.out.println(writeContentBean.getContent_text());
		//System.out.println(writeContentBean.getUpload_file());

		writeContentBean.setContent_writer_idx(loginUserBean.getUser_idx());
		
		boardMapper.addContentInfo(writeContentBean);


	}

}
